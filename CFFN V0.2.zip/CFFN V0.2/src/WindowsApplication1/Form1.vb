﻿Public Class Form1

    Dim random As Integer
    Dim Names(5495) As String
    Dim surname(88799) As String
    Dim strarr(2) As String
    Dim temparr(16881) As String
    Dim colour(16881) As String
    Dim hexHC(16881) As String
    Dim Ecolour(16881) As String
    Dim hexEC(16881) As String


    Private Sub BtnFName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnFName.Click

        FileOpen(1, ".../firstname.csv.csv", OpenMode.Input)
        For counter = 1 To 5494
            Names(counter) = LineInput(1)
        Next
        Randomize()
        random = Int(Rnd() * 5493) + 1
        RichTextBox1.Text = Names(random)
        FileClose(1)
    End Sub

    Private Sub FNrandom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FNrandom.Click
        random = Int(Rnd() * 5493) + 1
        RichTextBox1.Text = Names(random)
    End Sub



    Private Sub InitSurname_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InitSurname.Click
        FileOpen(2, ".../surname.csv", OpenMode.Input)
        For counter2 = 0 To 88797
            surname(counter2) = LineInput(2)
        Next
        Randomize()
        random = Int(Rnd() * 88798) + 1
        RichTextBox2.Text = surname(random)
        FileClose(2)
    End Sub

    Private Sub SurnameRandom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SurnameRandom.Click
        random = Int(Rnd() * 88798) + 1
        RichTextBox2.Text = surname(random)
    End Sub

    
    Private Sub InitHcolour_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InitHcolour.Click
        FileOpen(1, "colornames.csv", OpenMode.Input)
        
        For counter = 1 To 16881
            temparr(counter) = LineInput(1)
            strarr = temparr(counter).Split(",")
            colour(counter) = strarr(0)
            hexHC(counter) = strarr(1)
        Next
        FileClose(1)
        Randomize()
        random = Int(Rnd() * 16880) + 1
        HCtext.Text = colour(random)
        TxThcHex.Text = hexHC(random)
        HCcolour.BackColor = ColorTranslator.FromHtml(hexHC(random))
        FileClose(1)
    End Sub

  
    Private Sub HCrandom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HCrandom.Click
        random = Int(Rnd() * 16880) + 1
        HCtext.Text = colour(random)
        TxThcHex.Text = hexHC(random)
        HCcolour.BackColor = ColorTranslator.FromHtml(hexHC(random))
    End Sub


    Private Sub ECinit_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ECinit.Click
        FileOpen(1, "colornames.csv", OpenMode.Input)

        For counter = 1 To 16881
            temparr(counter) = LineInput(1)
            strarr = temparr(counter).Split(",")
            Ecolour(counter) = strarr(0)
            hexEC(counter) = strarr(1)
        Next

        Randomize()
        random = Int(Rnd() * 16880) + 1
        ECtxt.Text = Ecolour(random)
        EChexTxT.Text = hexEC(random)
        ECcolour.BackColor = ColorTranslator.FromHtml(hexEC(random))
        FileClose(1)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        random = Int(Rnd() * 16880) + 1
        ECtxt.Text = Ecolour(random)
        EChexTxT.Text = hexEC(random)
        ECcolour.BackColor = ColorTranslator.FromHtml(hexEC(random))
    End Sub


   
End Class
