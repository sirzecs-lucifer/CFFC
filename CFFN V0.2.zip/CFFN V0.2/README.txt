CFFN V0.2 release notes

-no longer have to put files in a certain directory, hust place with the exe file. 
-improved layout of the zip file


feel free to improve the source code, but please dont pass it off as your own, branch the master

~sirzecs 
