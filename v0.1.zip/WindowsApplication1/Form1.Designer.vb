﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnFName = New System.Windows.Forms.Button()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.FNrandom = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.InitSurname = New System.Windows.Forms.Button()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.SurnameRandom = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "first name"
        '
        'BtnFName
        '
        Me.BtnFName.Location = New System.Drawing.Point(84, 12)
        Me.BtnFName.Name = "BtnFName"
        Me.BtnFName.Size = New System.Drawing.Size(75, 20)
        Me.BtnFName.TabIndex = 6
        Me.BtnFName.Text = "initialise"
        Me.BtnFName.UseVisualStyleBackColor = True
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(165, 12)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(139, 20)
        Me.RichTextBox1.TabIndex = 7
        Me.RichTextBox1.Text = ""
        '
        'FNrandom
        '
        Me.FNrandom.Location = New System.Drawing.Point(310, 11)
        Me.FNrandom.Name = "FNrandom"
        Me.FNrandom.Size = New System.Drawing.Size(75, 20)
        Me.FNrandom.TabIndex = 8
        Me.FNrandom.Text = "random"
        Me.FNrandom.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 74)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "surname"
        '
        'InitSurname
        '
        Me.InitSurname.Location = New System.Drawing.Point(84, 70)
        Me.InitSurname.Name = "InitSurname"
        Me.InitSurname.Size = New System.Drawing.Size(75, 20)
        Me.InitSurname.TabIndex = 10
        Me.InitSurname.Text = "initialise"
        Me.InitSurname.UseVisualStyleBackColor = True
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Location = New System.Drawing.Point(165, 70)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(139, 20)
        Me.RichTextBox2.TabIndex = 11
        Me.RichTextBox2.Text = ""
        '
        'SurnameRandom
        '
        Me.SurnameRandom.Location = New System.Drawing.Point(310, 70)
        Me.SurnameRandom.Name = "SurnameRandom"
        Me.SurnameRandom.Size = New System.Drawing.Size(75, 20)
        Me.SurnameRandom.TabIndex = 12
        Me.SurnameRandom.Text = "random"
        Me.SurnameRandom.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(515, 514)
        Me.Controls.Add(Me.SurnameRandom)
        Me.Controls.Add(Me.RichTextBox2)
        Me.Controls.Add(Me.InitSurname)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.FNrandom)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.BtnFName)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BtnFName As System.Windows.Forms.Button
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents FNrandom As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents InitSurname As System.Windows.Forms.Button
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
    Friend WithEvents SurnameRandom As System.Windows.Forms.Button

End Class
